<WebServiceRequestEntity>
  <restRequestMethod>GET</restRequestMethod>
  <restUrl>https://mock.kafka/api/messages</restUrl>
</WebServiceRequestEntity>