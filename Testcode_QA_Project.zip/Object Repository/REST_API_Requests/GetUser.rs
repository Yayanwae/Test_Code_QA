<WebServiceRequestEntity>
  <restRequestMethod>GET</restRequestMethod>
  <restUrl>https://reqres.in/api/users/2</restUrl>
</WebServiceRequestEntity>