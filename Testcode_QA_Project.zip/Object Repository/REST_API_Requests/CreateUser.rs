<WebServiceRequestEntity>
  <restRequestMethod>POST</restRequestMethod>
  <restUrl>https://reqres.in/api/users</restUrl>
  <httpBodyContent>{"name":"QA Tester","job":"Automation"}</httpBodyContent>
</WebServiceRequestEntity>