# Testcode_QA - Katalon Project

Project ini dibuat sebagai bagian dari proses rekrutmen Quality Assurance dan mencakup pengujian:

## 🔹 RESTful API Testing (Katalon sebagai Producer & Consumer)

### 1. CreateUser (Producer)
- **Method**: POST
- **Endpoint**: `https://reqres.in/api/users`
- **Body**:
```json
{
  "name": "QA Tester",
  "job": "Automation"
}
```
- **Tujuan**: Mengirim data user baru.

### 2. GetUser (Consumer)
- **Method**: GET
- **Endpoint**: `https://reqres.in/api/users/2`
- **Tujuan**: Mengambil data user berdasarkan ID.

## 🔹 Kafka Simulation (Katalon sebagai Consumer)
### 3. ReadFromKafka
- **Method**: GET
- **Endpoint**: `https://mock.kafka/api/messages`
- **Tujuan**: Simulasi konsumsi pesan dari Kafka topic.

> Karena Katalon tidak mendukung Kafka native, maka digunakan simulasi endpoint sebagai pengganti REST Proxy Kafka.

## 📁 Struktur Folder

- `Test Cases/REST_API/TC_CreateUser`
- `Test Cases/REST_API/TC_GetUser`
- `Test Cases/Kafka_Test/TC_ReadFromKafka`
- `Object Repository/REST_API_Requests/`
- `Object Repository/Kafka_Consumer/`

## 📝 Cara Menjalankan

1. Buka project ini di **Katalon Studio**.
2. Jalankan masing-masing test case melalui panel `Test Cases`.
3. Pastikan hasil response sesuai dengan status code dan validasi property.

---

🕒 **Deadline Pengumpulan:** Kamis, 5 Juni 2025, pukul 19.00 WIB  
📤 **Kirim link repository ke email rekruter seperti instruksi pada email.**